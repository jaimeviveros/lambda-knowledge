const express = require('express')
const login = require('../src/index')
const app = express()
const port = 55000

var cors = require('cors')

app.use(cors()) 

app.post('/users/log/in', (req, res) => {
    login.handler()
        .then( (response) =>
            res.send(JSON.stringify(response.body))
        );
});

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})