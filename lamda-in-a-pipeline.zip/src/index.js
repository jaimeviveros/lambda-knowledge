
exports.handler = async (event) => {
    const vReturn = {
        in: true
    }
    // 
    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST"
        },
        body: vReturn,
    };
    return response;
};
